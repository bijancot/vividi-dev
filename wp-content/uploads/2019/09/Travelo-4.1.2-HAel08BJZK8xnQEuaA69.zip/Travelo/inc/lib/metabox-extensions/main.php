<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require_once( 'meta-box-conditional-logic/meta-box-conditional-logic.php' );
require_once( 'meta-box-tabs/meta-box-tabs.php' );