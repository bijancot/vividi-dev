<?php
/**
 * The Template for displaying tours in a cruise_line taxonomy . Simply includes the archive template.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

trav_get_template( 'archive-cruise.php' );