<?php
/**
 * The Template for displaying cars in a preference tag . Simply includes the archive template.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

trav_get_template( 'archive-car.php' );